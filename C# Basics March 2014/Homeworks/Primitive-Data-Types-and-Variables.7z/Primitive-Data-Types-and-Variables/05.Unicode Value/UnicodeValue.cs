﻿using System;


class UnicodeValue
{
    static void Main()
    {
        char a = '\u0048';
        Console.WriteLine("The unicode of 72 is {0}", a);
    }
}
