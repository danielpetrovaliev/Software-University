﻿using System;



class DeclareVariables
{
    static void Main()
    {
        ushort a = 52130;
        Console.WriteLine(a);
        sbyte b = -115;
        Console.WriteLine(b);
        uint c = 4825932;
        Console.WriteLine(c);
        byte d = 97;
        Console.WriteLine(d);
        short e = -10000;
        Console.WriteLine(e);
    }
}
