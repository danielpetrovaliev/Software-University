﻿using System;


class VariableInHexadecimalFormat
{
    static void Main()
    {
        int var = 0xFE;
        Console.WriteLine("Variable = {0}", var);
    }
}
