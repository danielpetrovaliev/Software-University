﻿using System;


class FloatOrDouble
{
    static void Main()
    {
        double d = 34.567839023d;
        Console.WriteLine(d);
        float f = 12.345f;
        Console.WriteLine(f);
        double g = 8923.1234857d;
        Console.WriteLine(g);
        float c = 3456.091f;
        Console.WriteLine(c);


    }
}
