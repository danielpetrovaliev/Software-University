﻿using System;


class GravitationMoon
{
    static void Main()
    {
        Console.WriteLine(double.Parse(Console.ReadLine())/100*17);
    }
}
