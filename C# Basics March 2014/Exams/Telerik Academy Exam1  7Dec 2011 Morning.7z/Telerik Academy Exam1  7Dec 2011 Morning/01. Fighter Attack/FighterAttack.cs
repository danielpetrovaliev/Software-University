﻿using System;


class FighterAttack
{
    static void Main()
    {
        int Px1 = int.Parse(Console.ReadLine());
        int Py1 = int.Parse(Console.ReadLine());
        int Px2 = int.Parse(Console.ReadLine());
        int Py2 = int.Parse(Console.ReadLine());
        int Fx = int.Parse(Console.ReadLine());
        int Fy = int.Parse(Console.ReadLine());
        int D = int.Parse(Console.ReadLine());

        int demage1 = 0;
        int demage2 = 0;
        int demage3 = 0;
        int demage4 = 0;
        int totaldemage;

        if (Px2 <= Fx + D && Fx + D <= Px2 - 1)
        {
            totaldemage+=
        }
    }
}