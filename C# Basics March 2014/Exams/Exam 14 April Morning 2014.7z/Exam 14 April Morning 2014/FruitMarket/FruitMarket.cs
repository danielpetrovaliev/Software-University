﻿using System;


class FruitMarket
{
    static void Main()
    {
        System.Threading.Thread.CurrentThread.CurrentCulture = System.Globalization.CultureInfo.InvariantCulture;
        string day = Console.ReadLine();
        decimal quantity1 = decimal.Parse(Console.ReadLine());
        string product1 = Console.ReadLine();
        decimal quantity2 = decimal.Parse(Console.ReadLine());
        string product2 = Console.ReadLine();
        decimal quantity3 = decimal.Parse(Console.ReadLine());
        string product3 = Console.ReadLine();

        decimal bananaPrice = 1.80m;
        decimal cucumberPrice = 2.75m;
        decimal tomatoPrice = 3.20m;
        decimal orangePrice = 1.60m;
        decimal applePrice = 0.86m;
        decimal totalPrice = 0;

        if ()
        {
            
        }
        
    }
}