﻿using System;


class PrintCurrentDataAndTime
{
    static void Main()
    {
        System.Console.WriteLine("The current date and time is " +System.DateTime.Now);
    }
}