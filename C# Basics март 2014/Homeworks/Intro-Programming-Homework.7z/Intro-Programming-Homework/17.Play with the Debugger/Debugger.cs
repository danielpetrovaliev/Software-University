﻿using System;


class Debugger
{
    static void Main()
    {
         for (int i = 1; i < 1001; i++)
         Console.WriteLine(i);
    }
}
