﻿using System;


class FirstLastName
{
    static void Main()
    {
        Console.WriteLine("First name - Daniel");
        Console.WriteLine("Last name - Petrovaliev");
    }
}
