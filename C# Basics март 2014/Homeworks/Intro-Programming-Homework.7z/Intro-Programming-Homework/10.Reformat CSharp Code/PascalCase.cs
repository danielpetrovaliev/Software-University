﻿using System;


class PascalCase
{
    static void Main()
    {
        Console.WriteLine("Program for Numbers and squares");
        Console.WriteLine("Numbers and squares:");
        for (int i = 0;i < 10;i++)
        {
            Console.WriteLine(i +" --> " + i*i);
        }
    }
}